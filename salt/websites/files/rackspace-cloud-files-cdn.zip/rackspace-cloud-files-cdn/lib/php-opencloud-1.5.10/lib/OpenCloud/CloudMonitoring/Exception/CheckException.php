<?php

namespace OpenCloud\CloudMonitoring\Exception;

class CheckException extends CloudMonitoringException
{
}
<?php

namespace OpenCloud\CloudMonitoring\Exception;

class NotificationPlanException extends CloudMonitoringException
{
}
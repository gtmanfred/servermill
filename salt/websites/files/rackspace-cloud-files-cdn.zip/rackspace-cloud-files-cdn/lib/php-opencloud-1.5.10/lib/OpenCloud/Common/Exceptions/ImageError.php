<?php

namespace OpenCloud\Common\Exceptions;

class ImageError extends \Exception {}

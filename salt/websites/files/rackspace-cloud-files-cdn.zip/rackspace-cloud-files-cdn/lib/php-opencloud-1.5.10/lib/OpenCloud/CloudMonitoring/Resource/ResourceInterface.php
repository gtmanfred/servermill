<?php

namespace OpenCloud\CloudMonitoring\Resource;

/**
 * ResourceInterface interface.
 */
interface ResourceInterface
{

    public function baseUrl();

}
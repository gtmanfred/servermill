<?php

namespace OpenCloud\CloudMonitoring\Exception;

class ZoneException extends CloudMonitoringException
{
}
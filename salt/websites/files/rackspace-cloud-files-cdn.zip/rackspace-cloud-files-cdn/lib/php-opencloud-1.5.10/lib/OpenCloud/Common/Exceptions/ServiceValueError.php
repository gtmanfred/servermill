<?php

namespace OpenCloud\Common\Exceptions;

class ServiceValueError extends \Exception {}

<?php

namespace OpenCloud\Common\Exceptions;

class DatabaseUpdateError extends \Exception {}

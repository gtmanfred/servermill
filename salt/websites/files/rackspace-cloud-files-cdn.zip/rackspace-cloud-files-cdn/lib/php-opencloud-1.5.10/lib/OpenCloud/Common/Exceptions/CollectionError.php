<?php

namespace OpenCloud\Common\Exceptions;

class CollectionError extends \Exception {}

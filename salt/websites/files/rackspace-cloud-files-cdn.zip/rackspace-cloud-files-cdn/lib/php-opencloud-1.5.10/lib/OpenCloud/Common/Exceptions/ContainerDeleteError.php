<?php

namespace OpenCloud\Common\Exceptions;

class ContainerDeleteError extends \Exception {}

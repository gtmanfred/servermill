<?php

namespace OpenCloud\CloudMonitoring\Exception;

class ServiceException extends CloudMonitoringException
{
}
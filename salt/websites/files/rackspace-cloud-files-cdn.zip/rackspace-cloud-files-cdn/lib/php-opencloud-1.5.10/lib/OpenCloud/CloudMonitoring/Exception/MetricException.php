<?php

namespace OpenCloud\CloudMonitoring\Exception;

class MetricException extends CloudMonitoringException
{
}
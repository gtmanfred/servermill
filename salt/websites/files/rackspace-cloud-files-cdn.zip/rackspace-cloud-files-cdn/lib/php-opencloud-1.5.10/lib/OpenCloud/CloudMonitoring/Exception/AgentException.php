<?php

namespace OpenCloud\CloudMonitoring\Exception;

class AgentException extends CloudMonitoringException
{
}